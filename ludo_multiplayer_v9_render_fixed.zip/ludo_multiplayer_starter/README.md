# Ludo Multiplayer v7

A Godot client + Node.js WebSocket server starter for an online 4-player Ludo game.

## What works
- Create/join 6-character room codes
- WebSocket online connection
- Server-authoritative dice and moves
- Four players per room
- Chat
- Turn handling, six-to-exit, extra turn, capture, winner state
- Docker + Render deployment files

## Run the server
See `server/README.md`.

## Run the Godot client
Open this folder in Godot 4.x and run the project. For a cloud server, change the server field to your `wss://...` address.

This is still a development build; production needs authentication, persistent accounts/leaderboards, reconnect support, TLS, rate limiting, and complete official Ludo rules.
